<html>
<head>
<title>Form validation</title>
</head>
<body>
<form action="" method="POST">
<input type="text" name="user">
<br><br>
<input type="text" name="email">
<br><br>
<button type="submit">Submit</button>
</form>
</body>
</html>